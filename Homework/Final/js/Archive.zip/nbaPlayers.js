$(document).ready(function () {
    $.ajax({
        type: "GET",
        url: "/js/nbaPlayers.xml",
        dataType: "xml",
        success: function(xml) { parseXml(xml); }
    });
    var test = " ";
    $('#dropDown').change(function() {
        hideDivs();
        test = $(this).val();
        $('#' + test).show();
    });
});
function parseXml(xml) {
    $(xml).find("Team").each(function () {
        var test = $(this).find("SYMID").text();
        $('#master-team').append('<div id="' + test + '"></div>')
        console.log(test);
        jQuery.each(test, function () {
            var first_name = $(this).find("Stat").attr("type=first_name");
            $('#' + test).append(first_name)
        });
 
    });
    hideDivs();

}
function hideDivs() {
    $('#BOS').hide();
    $('#ATL').hide();
    $('#NYK').hide();
    $('#PHI').hide();
    $('#TOR').hide();
    $('#BRO').hide();
    $('#CHA').hide();
    $('#MIA').hide();
    $('#WAS').hide();
    $('#UTA').hide();
    $('#SAC').hide();
    $('#POR').hide();
    $('#CLE').hide();
    $('#OKC').hide();
    $('#MIN').hide();
    $('#ORL').hide();
    $('#DET').hide();
    $('#CHI').hide();
    $('#NOH').hide();
    $('#MIL').hide();
    $('#MEM').hide();
    $('#IND').hide();
    $('#DAL').hide();
    $('#HOU').hide();
    $('#GS').hide();
    $('#SA').hide();
    $('#PHO').hide();
    $('#DEN').hide();
    $('#LAC').hide();
    $('#LAL').hide();
}